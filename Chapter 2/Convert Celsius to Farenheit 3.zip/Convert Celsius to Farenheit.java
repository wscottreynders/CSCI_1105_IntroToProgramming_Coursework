/* Author: Scott Reynders
	Date: 12/16/19
	
	Writing a program that converst Celsius to Fahrenheit
*/

class Untitled {
	public static void main(String[] args) {
		
		
		double Celsius;
		
		Celsius = 43;
		
	
		System.out.println(Celsius + " in degrees Celsius " + "is");
		
		System.out.println((9 * Celsius / 5) + 32 + " in degrees Fahrenheit ");
		
	}
}